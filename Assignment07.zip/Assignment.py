# -------------------------------------------------#
# Title: Exception Handling and Python Pickling
# Dev:   YZhao
# Date:  Dec/3/ 2018
# ChangeLog: (Who, When, What)
#   YZhao, 11/01/2018, Write three examples of Exceptions
#   YZhao, 11/02/2018, pickle and unpickle dictionary.
# -------------------------------------------------#
# different child class of exceptions customized for different errors


lstData = ["2", 0, "a"]  # give an set of data consist of number and letter
try:
    for i in range(0, 3):
        print(10 / float(lstData[i]))  # only 2 can give a correct answer
        continue
except ValueError as e:  # give notice when 0 is used as
    print(e)
except Exception as e:  # call a preexisted class when other error occurs.
    print(e)

#  reshuffle the order of data, see what changes
lstData = [2, "a", 0]  # give an set of data consist of number and letter
try:
    for i in range(0, 3):
        print(10 / float(lstData[i]))  # only 2 can give a correct answer
        continue
except ValueError as e:  # give notice when 0 is used as
    print(e)
except TypeError as e:  # call a preexisted class when other error occurs.
    print(e)

#  use tuple to specify multiple Exceptions
lstData = [2, "a", 0]  # give an set of data consist of number and letter
for i in range(0, 3):  # put every element into test
    try:
        print(10 / float(lstData[i]))  # only 2 can give a correct answer
    except (ZeroDivisionError, Exception)as e:  # two Exceptions put in one tuple
        print(e)  # print error

# start with dictionary
import pickle
# Data
dicStudent = {"Joe": 20, "Max": 21, "Bob": 23}  # dictionary of ages of student, index key is the name
# Processing
objFile = open("C:\_PythonClass\Assignment07\data.txt", "ab")  # ab stands for append binary
pickle.dump(dicStudent, objFile)
objFile = open("C:\_PythonClass\Assignment07\data.txt", "rb")   # rb stands for read binary
# I/O
print(pickle.load(objFile))



