# ----------------------------------#
# Title: Assignment 06
# Dev:   Yan Zhao
# Date:  Nov 26, 2018
# ChangeLog:(Who, When, What)
# Yan Zhao, 11/26/2018, Created Script
# -----------------------------------#
# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# start with copulating all functions into a class
class Menu(object):  # starting menu
    @staticmethod
    def Load():
        objFile = open("C:\_PythonClass\Assignment06\ToDoList.txt", "r")  # use"r" to read the file
        lstTask = []  # This make sure for loop return all the results
        for term in objFile.readlines():  # start of the loop
            strName = term.split(',')
            dicTask = {"Task": strName[0], "Priority": strName[1].strip("\n")}  # remember number starts at 0
            lstTask.append(dicTask)  # add dictionary to the list
        return lstTask   # notice only the right incantation can return all results
    @staticmethod
    def Options():   # Show the menu
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        print()  # adding a new line

    @staticmethod
    def ShowData(lstTask):  # Display all data from text
        print("list of tasks and priority", "\n", lstTask)

    @staticmethod
    def AddData(dicTask1):  # Add new data to list
        dicTask1 = {"Task": input("Task: "), "Priority": input("Priority: ")}
        lstTask.append(dicTask1)
        print("New Data added to list")

    @staticmethod
    def RemoveData(lstTask):
        print(lstTask)
        lstTask.pop(int(input("Please enter corresponding position number to remove item")))  # position starts at 0
        print("Data Removed")

    @staticmethod
    def SaveData(lstTask):
        strItem = str()  # This is very important, without it only the last result of loop would show
        for dicItem in lstTask:
            strTask = dicItem["Task"].title()  # extract task
            strPriority = dicItem["Priority"].lower()  # extract priority
            strItem += (strTask + ", " + strPriority + "\n")  # keep same format as original data
            objFile = open("C:\_PythonClass\Assignment06\ToDoList.txt", "w")
            objFile.write(strItem)
            objFile.close()
        print("Data Saved")

    @staticmethod
    def ExitProg():
        print("Program End")  # it does not really end program, I still need to put break in the loop


# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
lstTask = Menu.Load()
while True:  # create a loop
    # Step 2
    # Display a menu of choices to the user
    Menu.Options()  # just show the menu, it does not matter what parameter I use.
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    # Step 3
    # Display all todo items to user
    if strChoice == "1":  # use strip to get rid of ()
        Menu.ShowData(lstTask)
        continue
    # Step 4
    # Add a new item to the list/Table
    elif strChoice == "2":
        Menu.AddData(lstTask)  # parameter is the list from file
        continue
    # Step 5
    # Remove a new item to the list/Table
    elif strChoice == "3":
        Menu.RemoveData(lstTask)  # parameter is the list from file
    # Step 6
    # Save tasks to the ToDo.txt file
    elif strChoice == "4":
        Menu.SaveData(lstTask)  # parameter is the list from file
        continue
    # Step 7
    # Exit program
    elif strChoice == "5":
        Menu.ExitProg()  # no need for parameter, leave it blank
        break
