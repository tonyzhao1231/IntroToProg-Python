# ----------------------------------#
# Title: Home Inventory Script
# Dev:   Yan Zhao
# Date:  Nov 19, 2018
# ChangeLog:(Who, When, What)
# Yan Zhao, 11/17/2018, Created lite version
# Yan Zhao, 11/18/2018, Rewrite section for multi-function
# -----------------------------------#
# Step 1 load data from Task.txt into a dictionary
objFile = open("C:\_PythonClass\Assignment05\ToDo.txt", "r")  # use"r" to read the file
lstTask = []  # This make sure for loop return all the results
for term in objFile.readlines():  # start of the loop
    strName = term.split(',')
    dicTask = {"Task": strName[0], "Priority": strName[1].strip("\n")}  # remember number starts at 0
    lstTask.append(dicTask)  # add dictionary to the list
# Step 2 - Display a menu of choices to the user
while True:
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("list of tasks and priority","\n",lstTask)
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        dicTask1 = {"Task": input("Task: "), "Priority": input("Priority: ")}
        lstTask.append(dicTask1)
        print("New Data added to list")
        continue
    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        print(lstTask)
        lstTask.pop(int(input("Please enter corresponding position number to remove item")))  # position starts at 0
        print("Data Removed")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        strItem = str()  # This is very important, without it only the last result of loop would show
        for dicItem in lstTask:
            strTask = dicItem["Task"].title()   # extract task
            strPriority = dicItem["Priority"].lower()  # extract priority
            strItem += (strTask+", "+strPriority+"\n")  # keep same format as original data
            objFile.close()
            objFile = open("C:\_PythonClass\Assignment05\ToDo.txt", "w")
            objFile.write(strItem)
            objFile.close()
        print("Data Saved")
        continue
    # End program and save data again.
    elif (strChoice == '5'):
        objFile.close()
        objFile = open("C:\_PythonClass\Assignment05\ToDo.txt", "w")
        objFile.write(strItem)
        objFile.close()
        print("Data Saved","\n","Program End")
        break  # and Exit the program
